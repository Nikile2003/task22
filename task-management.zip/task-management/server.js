require("dotenv").config();
const express = require("express");
const mysql = require("mysql2");
const cors = require("cors");

const app = express();
app.use(express.json());
app.use(cors());

// Database connection
const db = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "Nikile2003@",
  database: "task_management",
});

db.connect((err) => {
  if (err) throw err;
  console.log("MySQL Connected...");
});

// Create a task
app.post("/tasks", (req, res) => {
  const { title, description, status, due_date } = req.body;
  const sql = "INSERT INTO tasks (title, description, status, due_date) VALUES (?, ?, ?, ?)";
  db.query(sql, [title, description, status, due_date], (err, result) => {
    if (err) throw err;
    res.json({ message: "Task added successfully", id: result.insertId });
  });
});

// Get all tasks
app.get("/tasks", (req, res) => {
  const sql = "SELECT * FROM tasks";
  db.query(sql, (err, results) => {
    if (err) throw err;
    res.json(results);
  });
});

// Update a task
app.put("/tasks/:id", (req, res) => {
  const { title, description, status, due_date } = req.body;
  const sql = "UPDATE tasks SET title=?, description=?, status=?, due_date=? WHERE id=?";
  db.query(sql, [title, description, status, due_date, req.params.id], (err, result) => {
    if (err) throw err;
    res.json({ message: "Task updated successfully" });
  });
});

// Delete a task
app.delete("/tasks/:id", (req, res) => {
  const sql = "DELETE FROM tasks WHERE id=?";
  db.query(sql, [req.params.id], (err, result) => {
    if (err) throw err;
    res.json({ message: "Task deleted successfully" });
  });
});

// Start server
app.listen(5000, () => {
  console.log("Server running on port 5000");
});
